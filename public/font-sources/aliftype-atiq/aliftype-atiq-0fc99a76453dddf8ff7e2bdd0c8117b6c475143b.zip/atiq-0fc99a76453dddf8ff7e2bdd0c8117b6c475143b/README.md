Atiq
=====

![Sample](FontSample.svg)

_Atiq_ (عتيق) is a manuscript Kufic typeface, intended to revive (as faithfully as
possible) the style of Kufic script used in writing the Qur’an in the third
century AH. _Atiq_ is Arabic for antiquated.

For more information:
> https://aliftype.com/atiq
